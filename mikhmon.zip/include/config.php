<?php 
if(substr($_SERVER["REQUEST_URI"], -10) == "config.php"){header("Location:./");}; 
$data['mikhmon'] = array ('1'=>'mikhmon<|<mikhmon','mikhmon>|>aWNlbA==');


$data['STAR4GLINK'] = array ('1'=>'STAR4GLINK!192.168.88.1','STAR4GLINK@|@admin','STAR4GLINK#|#mZWfoZ8=','STAR4GLINK%star4glink','STAR4GLINK^star4glink.net','STAR4GLINK&RS','STAR4GLINK*10','STAR4GLINK(4','STAR4GLINK)','STAR4GLINK=10','STAR4GLINK@!@enable');
